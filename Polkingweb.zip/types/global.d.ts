interface Window {
  va?: {
    track: (event: string, properties?: Record<string, any>) => void
  }
}
