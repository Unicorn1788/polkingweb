"use client"

import { useState } from "react"
import { useAppKit } from '@reown/appkit/react'
import { useAppKitAccount } from '@reown/appkit/react'
import { motion } from "framer-motion"
import { useToast } from "@/context/toast-context"
import { CONTRACT_ADDRESS } from "@/lib/constants"
import { getStakingPlan, stakePOL } from "@/lib/wagmi-config"
import type { Address } from "viem"

export function NFTBoosterSection() {
  const [isLoading, setIsLoading] = useState(false)
  const { showToast } = useToast()
  const { open } = useAppKit()
  const { address, isConnected } = useAppKitAccount()

  const handleStake = async () => {
    if (!isConnected || !address) {
      open()
      return
    }

    try {
      setIsLoading(true)
      const plan = await getStakingPlan(1000) // Default stake amount
      if (!plan) {
        throw new Error("Failed to get staking plan")
      }

      const tx = await stakePOL(1000, address as Address)
      showToast({
        type: "success",
        title: "Success",
        message: "Successfully staked POL tokens"
      })
    } catch (error) {
      console.error("Staking error:", error)
      showToast({
        type: "error",
        title: "Error",
        message: "Failed to stake POL tokens. Please try again."
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="py-16 bg-gradient-to-b from-gray-900 to-black"
    >
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Boost Your Rewards with NFT Staking
          </h2>
          <p className="text-gray-300 mb-8">
            Stake your POL tokens and earn additional rewards through our NFT booster program.
          </p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleStake}
            disabled={isLoading}
            className="px-8 py-3 bg-purple-600 text-white rounded-lg font-medium hover:bg-purple-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? "Staking..." : "Stake POL Tokens"}
          </motion.button>
        </div>
      </div>
    </motion.section>
  )
}
