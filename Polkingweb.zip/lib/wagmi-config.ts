import { cookieStorage, createStorage, http } from '@wagmi/core'
import { WagmiAdapter } from '@reown/appkit-adapter-wagmi'
import { polygon } from '@reown/appkit/networks'
import { readContract, writeContract } from "@wagmi/core"
import type { Address } from "viem"
import { parseEther } from "viem"
import POLKING from "@/app/contracts/POLKING.json"
import { logger } from "./logger"

// Get projectId from environment
export const projectId = process.env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID

if (!projectId) {
  throw new Error('Project ID is not defined')
}

export const POLKING_ADDRESS = process.env.NEXT_PUBLIC_POLKING_ADDRESS || ""

// Set up the Wagmi Adapter (Config)
export const wagmiAdapter = new WagmiAdapter({
  storage: createStorage({
    storage: cookieStorage
  }),
  ssr: true,
  projectId,
  networks: [polygon],
  metadata: {
    name: "Polking Finance",
    description: "Stake like a king. Rise through the ranks. Reign with rewards.",
    url: "https://polking.io",
    icons: ["https://polking.io/images/polking-logo.png"],
  }
})

export const config = wagmiAdapter.wagmiConfig

// Export contract config with proper types
export const contractConfig = {
  address: POLKING_ADDRESS as `0x${string}`,
  abi: POLKING.abi,
} as const

// Export contract write config
export const contractWriteConfig = {
  ...contractConfig,
  functionName: "stake",
} as const

export type ContractConfig = typeof contractConfig
export type ContractWriteConfig = typeof contractWriteConfig

// Initialize wagmi client
export const initializeWagmi = () => {
  return config
}

// Utility function to get staking plan details with retry
export async function getStakingPlan(amount: number): Promise<number | null> {
  if (!amount) return null
  
  let retries = 3
  while (retries > 0) {
    try {
      const plan = await readContract(config, {
        abi: POLKING.abi,
        address: POLKING_ADDRESS as `0x${string}`,
        functionName: "getPlan",
        args: [parseEther(amount.toString())],
      })
      
      return Number(plan)
    } catch (error) {
      retries--
      if (retries === 0) {
        logger.error("Error getting plan after retries:", error)
        return null
      }
      await new Promise(resolve => setTimeout(resolve, 1000 * (3 - retries)))
    }
  }
  return null
}

// Get plan details (rate and duration)
export async function getPlanRate(plan: number): Promise<{ roiBps: number; durationDays: number }> {
  try {
    const result = await readContract(config, {
      abi: POLKING.abi,
      address: POLKING_ADDRESS as `0x${string}`,
      functionName: "getRate",
      args: [plan],
    })
    
    const typedResult = result as [bigint, bigint]
    
    return {
      roiBps: Number(typedResult[0]),
      durationDays: Number(typedResult[1]),
    }
  } catch (error) {
    logger.error("Error getting plan rate:", error)
    return { roiBps: 0, durationDays: 0 }
  }
}

// Get user's staking balance
export async function getUserStakingAmount(address: Address): Promise<number> {
  try {
    const amount = await readContract(config, {
      abi: POLKING.abi,
      address: POLKING_ADDRESS as `0x${string}`,
      functionName: "getStakeAmount",
      args: [address],
    })
    
    return Number(amount)
  } catch (error) {
    logger.error("Error getting user stake amount:", error)
    return 0
  }
}

// Stake POL tokens with a referrer
export async function stakePOL(amount: number, referrer: Address): Promise<`0x${string}`> {
  try {
    const tx = await writeContract(config, {
      abi: POLKING.abi,
      address: POLKING_ADDRESS as `0x${string}`,
      functionName: "stake",
      args: [referrer],
      value: parseEther(amount.toString()),
    })
    
    return tx
  } catch (error) {
    logger.error("Error staking:", error)
    throw error
  }
}

// Get active stakes count
export async function getActiveStakesCount(address: Address): Promise<number> {
  try {
    const count = await readContract(config, {
      abi: POLKING.abi,
      address: POLKING_ADDRESS as `0x${string}`,
      functionName: "activeStakesCount",
      args: [address],
    })
    
    return Number(count)
  } catch (error) {
    logger.error("Error getting active stakes count:", error)
    return 0
  }
}

// Claim rewards
export async function claimRewards(): Promise<`0x${string}`> {
  try {
    const tx = await writeContract(config, {
      abi: POLKING.abi,
      address: POLKING_ADDRESS as `0x${string}`,
      functionName: "claim",
    })
    
    return tx
  } catch (error) {
    logger.error("Error claiming rewards:", error)
    throw error
  }
}

// Get rewards data
export async function getRewardsData(address: Address): Promise<{ totalUnclaimed: number; rewardsPerSecond: number }> {
  try {
    const data = await readContract(config, {
      abi: POLKING.abi,
      address: POLKING_ADDRESS as `0x${string}`,
      functionName: "getLiveRewardsData",
      args: [address],
    })
    
    const typedData = data as [bigint, bigint]
    
    return {
      totalUnclaimed: Number(typedData[0]),
      rewardsPerSecond: Number(typedData[1]),
    }
  } catch (error) {
    logger.error("Error getting rewards data:", error)
    return { totalUnclaimed: 0, rewardsPerSecond: 0 }
  }
}

export default config
