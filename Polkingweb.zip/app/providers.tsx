"use client"

import { QueryClient, QueryClientProvider } from "@tanstack/react-query"
import { createAppKit } from '@reown/appkit/react'
import { polygon } from '@reown/appkit/networks'
import React, { type ReactNode } from 'react'
import { cookieToInitialState, WagmiProvider, type Config } from 'wagmi'
import { NotificationProvider } from "@/context/notification-context"
import { ToastProvider } from "@/context/toast-context"
import { Notification } from "@/components/ui/notification"
import { WalletModalContainer } from "@/components/wallet-modal-container"
import { Analytics } from "@vercel/analytics/react"
import { SpeedInsights } from "@vercel/speed-insights/next"
import { wagmiAdapter, projectId } from '@/config'

// Set up queryClient
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60 * 1000,
      refetchOnWindowFocus: false,
    },
  },
})

if (!projectId) {
  throw new Error('Project ID is not defined')
}

// Set up metadata
const metadata = {
  name: 'Polking Finance',
  description: 'Stake like a king. Rise through the ranks. Reign with rewards.',
  url: 'https://polking.io',
  icons: ['https://polking.io/images/polking-logo.png']
}

// Create the AppKit instance
const appKit = createAppKit({
  adapters: [wagmiAdapter],
  projectId,
  networks: [polygon],
  defaultNetwork: polygon,
  metadata: metadata,
  features: {
    analytics: true
  }
})

interface ProvidersProps {
  children: ReactNode
  cookies?: string | null
}

export function Providers({ children, cookies }: ProvidersProps) {
  const initialState = React.useMemo(() => {
    if (!cookies) return undefined
    try {
      return cookieToInitialState(wagmiAdapter.wagmiConfig as Config, cookies)
    } catch (error) {
      console.error('Failed to parse cookie state:', error)
      return undefined
    }
  }, [cookies])

  return (
    <WagmiProvider config={wagmiAdapter.wagmiConfig as Config} initialState={initialState}>
      <QueryClientProvider client={queryClient}>
        <NotificationProvider>
          <ToastProvider>
            {children}
            <Notification />
            <WalletModalContainer />
            <Analytics />
            <SpeedInsights />
          </ToastProvider>
        </NotificationProvider>
      </QueryClientProvider>
    </WagmiProvider>
  )
}
